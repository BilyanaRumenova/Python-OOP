from unittest import TestCase, main

from project.card.magic_card import MagicCard


class TestBattleField(TestCase):
    def setUp(self):
        pass

    def test_attributes_are_set(self):
        pass

    def test_check_class_name(self):
        self.assertEqual("MagicCard", self.magic_card.__class__.__name__)


if __name__ == '__main__':
    main()